import * as actionTypes from "./actions";
const initialState = {
 
  channels: [],
  partners:[],
 
};

const reducer = (state = initialState, action) => {
  let trigger = [];
  let open = [];
  switch (action.type) {
    case actionTypes.FETCH_CHANNEL:
      return {
        ...state,
        channels: action.payload,
      };

    case actionTypes.FETCH_PARTNERS:
      return {
        ...state,
        partners: action.payload,
      };
    default:
      return state;
  }
};

export default reducer;
