const DEMO = {
    BLANK_LINK: null,
    LOGIN: "/login",
  };
  export default DEMO;