import { httpGetRequest } from "../action/httpRequests";

import * as actionTypes from "./actions";


export const fetchChannels = (dispatch, callback) => {
  const url ="http://localhost/api/api.php";
  // httpGetRequest(url, (response) => {
  //   if (callback) callback(response.data ? response.data : []);
  //   return dispatch({
  //     type: actionTypes.FETCH_CHANNEL,
  //     payload: response.data ? response.data : [],
  //   });
  // });


  return dispatch({
    type: actionTypes.FETCH_CHANNEL,
    payload: {
      "name": "John Doe",
      "age": 30,
      "city": "New York",
      "skills": [
        "PHP",
        "JavaScript",
        "MySQL"
      ],
      "is_active": true,
      "additional_info": {
        "email": "johndoe@example.com",
        "phone": "123-456-7890"
      }
    },
  });

};
export const fetchPartners = (dispatch, callback) => {
  const url ="http://localhost/api/api.php";
  // httpGetRequest(url, (response) => {
  //   if (callback) callback(response.data ? response.data : []);
  //   return dispatch({
  //     type: actionTypes.FETCH_CHANNEL,
  //     payload: response.data ? response.data : [],
  //   });
  // });

  return dispatch({
    type: actionTypes.FETCH_CHANNEL,
    payload: {
      "name": "John Doe",
      "age": 30,
      "city": "New York",
      "skills": [
        "PHP",
        "JavaScript",
        "MySQL"
      ],
      "is_active": true,
      "additional_info": {
        "email": "johndoe@example.com",
        "phone": "123-456-7890"
      }
    },
  });
};



