import React, { useEffect, useState } from 'react';



export const AccountingIgnoredList = (props) => {

  console.log("props");
  console.log(props);
  
  const [showButton, setShowButton] = useState(true);
  const [ignoredList, setIgnoredList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchparams] = useState('');

  const [datalength, SetDataLenght] = useState(0);
  const [page, setPage] = useState(0);
  const [limit] = useState(30);
  const [isReset, SetIsReset] = useState(false);

  useEffect(() => {
    let mounted = true;
    if (mounted) {

    }
    return () => {
      mounted = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchparams]);


  return (
    <div>
      <h1>Hello world</h1>
      <div onClick={()=>{
        console.log('clicked');
        props.fetchChannels();
      }} >click</div>
    </div>
  );
};
