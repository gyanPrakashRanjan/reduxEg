// App.js
import React from "react";
import { connect } from "react-redux";
import { fetchChannels, fetchPartners } from "./store/actionCreator";
import { AccountingIgnoredList } from "./MyComponent";

function App(props) {
  return <AccountingIgnoredList {...props} />;
}

const mapStateToProps = (state) => {
  return {
    channels: state.channels,
    partners: state.partners,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    fetchChannels: (callback) => fetchChannels(dispatch, callback),
    fetchPartners: (callback) => fetchPartners(dispatch, callback),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App);

